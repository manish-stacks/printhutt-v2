import { blogFrontService } from '@/_services/common/blogService';
import BlogDetails from '@/views/BlogDetails';
import { Metadata } from 'next';
import { notFound } from 'next/navigation';

interface Props {
    params: Promise<{
    slug: string;
  }>;
}


export async function generateMetadata({ params }: Props): Promise<Metadata> {
  try {
    const { slug } =await params;
    const blog = await blogFrontService.getBlogDetails(slug);

    if (!blog) {
      return {
        title: 'Blog Details',
        description: 'Blog information',
      };
    }

    return {
      title: blog.blogPost?.metaTitle || 'Blog Details',
      description: blog.blogPost?.metaDescription || '',
      keywords: blog.blogPost?.metaKeywords || '',
      openGraph: {
        images: blog.blogPost?.image?.url || '',
      },
    };
  } catch {
    return {
      title: 'Blog Details',
      description: 'Blog information',
    };
  }
}

export default async function BlogDetailsPage({ params }: Props) {
  try {
    const { slug } =await params;
    const response = await blogFrontService.getBlogDetails(slug);

    if (!response) {
      return notFound();
    }

    return <BlogDetails blogData={response.blogPost} relatedBlog={response.relatedBlogs} />;
  } catch {
    return notFound();
  }
}
