/**
 * Centralized axios instance for the extracted backend.
 *
 * Behaviour preserved from the original frontend:
 *   - Response interceptor unwraps `response.data` automatically so callers
 *     can do `const result = await axiosInstance.get(...)` and use `result`
 *     directly as the JSON body. TypeScript callers receive `<T>` directly
 *     instead of `AxiosResponse<T>`.
 *
 * New behaviour:
 *   - withCredentials: true — sends httpOnly cookies (access_token / refresh_token / token).
 *   - On 401, automatically calls /auth/refresh once and retries the original
 *     request transparently. Concurrent 401s queue up until refresh completes.
 *   - Error normalization preserved — error.message carries the server message.
 */
import axios, {
  AxiosError,
  AxiosInstance,
  AxiosRequestConfig,
  InternalAxiosRequestConfig,
} from 'axios';

const API_URL =
  process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

// ── Type override ────────────────────────────────────────────────────────
// Our interceptor returns `response.data`, so each verb resolves directly
// to T (the body) instead of `AxiosResponse<T>`. We re-declare the verb
// signatures so consumers get the right inferred type.
interface UnwrappedAxios extends Omit<AxiosInstance, 'get' | 'post' | 'put' | 'patch' | 'delete' | 'head' | 'options'> {
  <T = any>(config: AxiosRequestConfig): Promise<T>;
  <T = any>(url: string, config?: AxiosRequestConfig): Promise<T>;
  get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T>;
  post<T = any>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T>;
  put<T = any>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T>;
  patch<T = any>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T>;
  delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T>;
  head<T = any>(url: string, config?: AxiosRequestConfig): Promise<T>;
  options<T = any>(url: string, config?: AxiosRequestConfig): Promise<T>;
}

const _axios = axios.create({
  baseURL: API_URL,
  withCredentials: true,
  timeout: 30000,
});

export const axiosInstance = _axios as unknown as UnwrappedAxios;

/* ── In-memory access token (mobile/SSR clients) ─────────────────── */
let inMemoryAccessToken: string | null = null;
export const setAccessToken = (t: string | null): void => {
  inMemoryAccessToken = t;
};

_axios.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (inMemoryAccessToken) {
    config.headers.set('Authorization', `Bearer ${inMemoryAccessToken}`);
  }
  return config;
});

/* ── Response interceptor: unwrap + auto-refresh on 401 ─────────── */
interface PendingItem {
  resolve: (token: string | null) => void;
  reject: (err: unknown) => void;
}
let isRefreshing = false;

/* Guest (kabhi login nahi) pe /auth/refresh call hi mat karo → console 401 spam band.
   Session hint zustand persist (user-store) se aata hai; mount pe /auth/session server-side
   refresh kar ke isse sync rakhta hai. */
const hasSessionHint = (): boolean => {
  if (typeof window === 'undefined') return false;
  try {
    const raw = localStorage.getItem('user-store');
    return !!(raw && JSON.parse(raw)?.state?.isLoggedIn);
  } catch {
    return false;
  }
};
let pending: PendingItem[] = [];

const drainQueue = (err: unknown, token: string | null): void => {
  pending.forEach((p) => (err ? p.reject(err) : p.resolve(token)));
  pending = [];
};

_axios.interceptors.response.use(
  (response) => response.data,
  async (error: AxiosError) => {
    const original = error.config as
      | (AxiosRequestConfig & { _retry?: boolean })
      | undefined;

    // Preserve error message handling
    const message =
      (error.response?.data as { message?: string; error?: string } | undefined)?.message ||
      (error.response?.data as { message?: string; error?: string } | undefined)?.error ||
      error.message ||
      'An unexpected error occurred';
    error.message = message;

    const url = original?.url ?? '';
    const isAuthEndpoint =
      url.includes('/auth/login') ||
      url.includes('/auth/admin-login') ||
      url.includes('/auth/verify-otp') ||
      url.includes('/auth/refresh') ||
      url.includes('/auth/session') ||
      url.includes('/auth/logout') ||
      url.includes('/auth/signup');

    if (error.response?.status !== 401 || !original || original._retry || isAuthEndpoint) {
      return Promise.reject(error);
    }

    // Guest → refresh try karne ka matlab nahi (refresh cookie hai hi nahi)
    if (!hasSessionHint()) {
      return Promise.reject(error);
    }

    original._retry = true;

    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        pending.push({
          resolve: (token) => {
            if (token) {
              original.headers = { ...original.headers, Authorization: `Bearer ${token}` };
            }
            resolve(_axios(original));
          },
          reject,
        });
      });
    }

    isRefreshing = true;
    try {
      const refreshRes = await axios.post(
        `${API_URL}/auth/refresh`,
        {},
        { withCredentials: true }
      );
      const newToken = (refreshRes.data as { accessToken?: string }).accessToken ?? null;
      if (newToken) setAccessToken(newToken);
      drainQueue(null, newToken);
      if (newToken) {
        original.headers = { ...original.headers, Authorization: `Bearer ${newToken}` };
      }
      return _axios(original);
    } catch (refreshErr) {
      drainQueue(refreshErr, null);
      setAccessToken(null);
      // ⚠️ Bug #3 fix: Payment / order / verify ke beech token expire ho to
      //    GLOBAL logout mat firao. Gateway redirect (PhonePe/Razorpay) ke baad
      //    aksar cookie context kho jata tha → refresh fail → user logout.
      //    In endpoints par sirf request fail hone do, session intact rahe.
      const skipExpiry =
        url.includes('/payment') ||
        url.includes('/orders') ||
        url.includes('/auth/me');
      if (typeof window !== 'undefined' && !skipExpiry) {
        window.dispatchEvent(new CustomEvent('auth:expired'));
      }
      return Promise.reject(refreshErr);
    } finally {
      isRefreshing = false;
    }
  }
);
